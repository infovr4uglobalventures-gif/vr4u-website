import React, { useState } from 'react';

export default function App() {
  const [active, setActive] = useState('venture');
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  function handleChange(e) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    alert(`Thanks ${form.name || 'there'} — we received your message!`);
    setForm({ name: '', email: '', message: '' });
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-teal-400 flex items-center justify-center text-white font-bold">VR</div>
            <div>
              <h1 className="text-lg font-semibold">VR4U Group</h1>
              <p className="text-xs text-gray-500">VR4U Global Venture &amp; VR4U Enterprises</p>
            </div>
          </div>

          <nav className="flex items-center space-x-4">
            <button
              onClick={() => setActive('venture')}
              className={`px-3 py-2 rounded-md text-sm ${active === 'venture' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`}>
              VR4U Global Venture
            </button>
            <button
              onClick={() => setActive('enterprises')}
              className={`px-3 py-2 rounded-md text-sm ${active === 'enterprises' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`}>
              VR4U Enterprises
            </button>
            <a href="#contact" className="px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100">Contact</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Hero */}
        <section className="grid md:grid-cols-2 gap-8 items-center mb-12">
          <div>
            <h2 className="text-3xl font-extrabold leading-tight">{active === 'venture' ? 'VR4U Global Venture' : 'VR4U Enterprises'}</h2>
            <p className="mt-4 text-gray-600 max-w-xl">
              {active === 'venture'
                ? 'A forward-looking parent company focused on strategic growth across automotive, logistics, construction materials, and financial services. We build trusted brands and create long-term value through operational excellence and customer-first innovation.'
                : 'A versatile operating arm delivering exceptional automotive services — used cars, workshops, tyre & wheel alignment, body shop and accessories — alongside transportation and insurance solutions to support mobility and customer care.'}
            </p>

            <div className="mt-6 flex space-x-3">
              <a href="#services" className="inline-block px-5 py-3 bg-blue-600 text-white rounded-md font-medium">Our Services</a>
              <a href="#contact" className="inline-block px-5 py-3 border border-gray-200 rounded-md text-sm">Get in touch</a>
            </div>
          </div>

          <div className="rounded-xl bg-white shadow p-6">
            <h3 className="font-semibold mb-3">Quick facts</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li><strong>Industries:</strong> Automotive, Logistics, Stone &amp; Construction Materials, Insurance</li>
              <li><strong>Offerings:</strong> Used cars, servicing, body shop, tyres, accessories, transport, insurance sales</li>
              <li><strong>Approach:</strong> Customer trust, quality workmanship, end-to-end solutions</li>
            </ul>
          </div>
        </section>

        {/* Company Description */}
        <section className="mb-12 bg-white rounded-xl shadow p-8">
          <h3 className="text-2xl font-bold mb-4">V4U Global – Company Description</h3>
          <p className="text-gray-700 leading-relaxed">
            V4U Global is a diversified parent company with a strong presence across the automotive and allied industries. Established with a vision to deliver quality, trust, and innovation, V4U Global oversees multiple business verticals that serve a wide range of customer needs under one trusted brand.
          </p>
          <p className="mt-4 text-gray-700 leading-relaxed">
            In the automotive sector, V4U Global operates used car showrooms, providing customers with reliable pre-owned vehicles, along with comprehensive service centers that handle everything from routine maintenance to advanced mechanical repairs. The company also runs specialized facilities for tyre and wheel alignment, body shop services, and a fully equipped accessory shop, making it a one-stop destination for vehicle care and enhancement.
          </p>
          <p className="mt-4 text-gray-700 leading-relaxed">
            Beyond automotive services, V4U Global has expanded into diverse industries. The group is engaged in the stone business, offering high-quality materials for construction and design projects. It also operates a transportation division, ensuring dependable logistics and mobility solutions. Additionally, V4U Global extends its expertise to the financial sector with dedicated services in auto insurance and health insurance sales, supporting customers in safeguarding their assets and well-being.
          </p>
          <p className="mt-4 text-gray-700 leading-relaxed">
            By uniting multiple businesses under a single umbrella, V4U Global demonstrates its commitment to growth, customer satisfaction, and long-term value creation. The company continues to build trust across industries through professional service, transparent practices, and a forward-looking approach.
          </p>
        </section>

        {/* Services */}
        <section id="services" className="mb-12">
          <h3 className="text-2xl font-bold mb-4">Services &amp; Capabilities</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card title="Used Car Showrooms" body="Curated selection of inspected pre-owned vehicles with transparent history and financing support." />
            <Card title="Service &amp; Repair" body="Full-service workshops for routine maintenance to advanced mechanical work with OEM-grade parts." />
            <Card title="Tyres &amp; Wheel Alignment" body="Specialized centres with precision alignment and premium tyre options." />
            <Card title="Body Shop &amp; Accessories" body="Paint, dent repair, customization and a stocked accessory shop to personalize vehicles." />
            <Card title="Logistics &amp; Transport" body="Reliable transportation services for commercial and private mobility needs." />
            <Card title="Stone &amp; Materials" body="High-quality stone and construction materials for builders and designers." />
            <Card title="Auto Insurance" body="Brokerage and sales for vehicle insurance tailored for different customer needs." />
            <Card title="Health Insurance" body="Health insurance options to protect employees and families." />
          </div>
        </section>

        {/* Values */}
        <section className="mb-12 bg-white rounded-xl shadow p-8">
          <h3 className="text-xl font-semibold mb-4">Values that drive us</h3>
          <div className="grid sm:grid-cols-3 gap-6 text-gray-700">
            <Value title="Trust &amp; Transparency" text="Clear pricing, honest inspections and straightforward customer communication." />
            <Value title="Quality &amp; Safety" text="Adherence to safety standards and rigorous quality checks across services." />
            <Value title="Innovation &amp; Growth" text="Continuous improvement and expansion into complementary verticals for resilience." />
          </div>
        </section>

        {/* About sections */}
        <section className="mb-12 grid md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-white rounded-xl p-6">
            <h4 className="font-semibold mb-3">About VR4U Global Venture</h4>
            <p className="text-gray-700">VR4U Global Venture is the investment and holding arm focused on strategic portfolio management, brand stewardship and cross-vertical synergies. It identifies new opportunities, supports growth-stage initiatives and ensures governance and compliance across the group.</p>
          </div>
          <div className="bg-gradient-to-br from-teal-50 to-white rounded-xl p-6">
            <h4 className="font-semibold mb-3">About VR4U Enterprises</h4>
            <p className="text-gray-700">VR4U Enterprises is the operational engine—managing showrooms, service centres, logistics, and insurance operations. Its emphasis is on service excellence, operational efficiency, and customer delight.</p>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="mb-20">
          <h3 className="text-2xl font-bold mb-4">Contact Us</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <form name="contact" method="POST" data-netlify="true" netlify-honeypot="bot-field" action="/thank-you" className="space-y-4 bg-white rounded-xl shadow p-6">
  <input type="hidden" name="form-name" value="contact" />
  <p className="hidden">
    <label>Don’t fill this out if you’re human: <input name="bot-field" /></label>
  </p>
  <div>
    <label className="block text-sm font-medium">Name</label>
    <input name="name" className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" placeholder="Your name" required />
  </div>
  <div>
    <label className="block text-sm font-medium">Email</label>
    <input name="email" type="email" className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" placeholder="you@example.com" required />
  </div>
  <div>
    <label className="block text-sm font-medium">Message</label>
    <textarea name="message" rows={4} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" placeholder="How can we help?" required></textarea>
  </div>
  <div className="flex items-center justify-between">
    <div className="text-sm text-gray-500">Prefer phone? Call: +91-XXXXXXXXXX</div>
    <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">Send message</button>
  </div>
</form>


            <div className="space-y-4">
              <div className="bg-white rounded-xl shadow p-6">
                <h5 className="font-semibold">Headquarters</h5>
                <p className="text-sm text-gray-600">123 Corporate Avenue, Business Park, City, Country</p>
                <p className="mt-2 text-sm">Email: hello@vr4u.example</p>
                <p className="text-sm">Phone: +91-XXXXXXXXXX</p>
              </div>

              <div className="bg-white rounded-xl shadow p-6">
                <h5 className="font-semibold">Follow us</h5>
                <p className="text-sm text-gray-600">LinkedIn • Instagram • Facebook</p>
              </div>
            </div>
          </div>
        </section>

        <footer className="text-center py-6 text-sm text-gray-500">
          © {new Date().getFullYear()} VR4U Group. All rights reserved.
        </footer>
      </main>
    </div>
  );
}

function Card({ title, body }) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h4 className="font-semibold mb-2">{title}</h4>
      <p className="text-sm text-gray-600">{body}</p>
    </div>
  );
}

function Value({ title, text }) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h5 className="font-medium">{title}</h5>
      <p className="text-sm mt-2">{text}</p>
    </div>
  );
}
