import React from 'react';
import { Link } from 'react-router-dom';

export default function ThankYou() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-6">
      <div className="bg-white rounded-xl shadow p-10 text-center max-w-lg">
        <h1 className="text-3xl font-bold mb-4 text-blue-600">Thank You!</h1>
        <p className="mb-6 text-gray-700">Thank you for contacting VR4U Global. Our team will reach out to you shortly.</p>
        <Link to="/" className="px-6 py-3 bg-blue-600 text-white rounded-md">Back to Home</Link>
      </div>
    </div>
  );
}
